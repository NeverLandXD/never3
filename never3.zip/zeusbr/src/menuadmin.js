const menuadmin = (prefix, sender) => {
	return `
  ❍𝙼𝙴𝙽𝚄 𝙰𝙳𝙼𝙸𝙽
  
 ║➩ ❍ #abrirgp
 ║➩ ❍ #fechargp
 ║➩ ❍ #setname
 ║➩ ❍ #setdesc
 ║➩ ❍ #promover
 ║➩ ❍ #rebaixar
 ║➩ ❍ #marcar
 ║➩ ❍ #marcar2
 ║➩ ❍ #marcar3
 ║➩ ❍ #marcar4
 ║➩ ❍ #marcar5
 ║➩ ❍ #add
 ║➩ ❍ #remover
 ║➩ ❍ #listadmins
 ║➩ ❍ #linkgp
 ║➩ ❍ #sairgp
 ║➩ ❍ #bv
 ║➩ ❍ #nsfw
 ║➩ ❍ #leveling
 ║➩ ❍ #leveling
 ║➩ ❍ #apagar
 ║➩ ❍ #simih
`
}

exports.menuadmin = menuadmin
